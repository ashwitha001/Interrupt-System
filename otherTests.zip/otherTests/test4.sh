g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace4.txt execution4.txt
