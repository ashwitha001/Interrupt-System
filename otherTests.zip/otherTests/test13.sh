g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace13.txt execution13.txt