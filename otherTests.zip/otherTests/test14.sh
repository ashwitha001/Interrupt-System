g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace14.txt execution14.txt