g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace10.txt execution10.txt