g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace6.txt execution6.txt