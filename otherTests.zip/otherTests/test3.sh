g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace3.txt execution3.txt
