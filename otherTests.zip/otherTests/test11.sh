g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace11.txt execution11.txt