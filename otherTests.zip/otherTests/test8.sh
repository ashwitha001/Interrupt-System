g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace8.txt execution8.txt