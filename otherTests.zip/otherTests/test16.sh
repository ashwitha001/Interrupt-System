g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace16.txt execution16.txt