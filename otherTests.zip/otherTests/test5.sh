g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace5.txt execution5.txt