g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace17.txt execution17.txt