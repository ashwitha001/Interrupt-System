g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace12.txt execution12.txt