g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace20.txt execution20.txt