g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace9.txt execution9.txt