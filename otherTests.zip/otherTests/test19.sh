g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace19.txt execution19.txt