g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace18.txt execution18.txt