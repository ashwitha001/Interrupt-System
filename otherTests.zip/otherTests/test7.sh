g++ interrupts.cpp -I interrupts.hpp -o sim
./sim trace7.txt execution7.txt